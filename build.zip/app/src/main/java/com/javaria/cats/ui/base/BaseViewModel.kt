package com.javaria.cats.ui.base

import androidx.lifecycle.ViewModel
import com.javaria.cats.data.repositories.BaseRepository

abstract class BaseViewModel(private val repository: BaseRepository) : ViewModel() {




}